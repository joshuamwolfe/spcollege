let http = require('http');

let optionsGet = {
    hostname: 'localhost',
    port: '3000',
  };

let optionsPost = {
    host: '127.0.0.1',
    path: '/',
    port: '8080',
    method: 'POST'
};

let fakeArray = [
    'Issue One', 
    'Issue Two', 
    'Issue Three',
    'Issue Four',
    'Issue Five'
]

http.createServer(function (req,res) {
    let jsonData = "";
    req.on('data', function (dataChunk) {
        jsonData += dataChunk;
    });

    req.on('end', function () {
        let reqObj = JSON.parse(jsonData);

        let resObj = {
            message: 'Hello, ' + reqObj.name,
            question: 'Please explain the issue'
        };

        res.writeHead(200);
        res.end(JSON.stringify(resObj));
    });
}).listen(3000);

function retrieveAllIssues(response) {
    let responseData = '';

    response.on('data', function (chunk) {
        responseData += chunk;
    });  

    response.on('end', function () {
        let dataObj = JSON.parse(responseData);
        console.log("Raw Response: " +responseData);
        console.log("Message: " + dataObj.message);
        console.log("Question: " + dataObj.question);
    });
}

function postIssue(response) {
    let serverData = '';
    response.on('data', function (chunk) {
        serverData += chunk;
    });

    response.on('end', function () {
        console.log("Response Status:", response.statusCode);
        console.log("Response Headers:", response.headers);    
        console.log(serverData);
    });
}

let req = http.request(options, readJSONResponse);
req.write('{"name":"Bilbo", "occupation":"Burglar"}');
req.end();

/*
-----------------------------------------
abondoned ideas
-----------------------------------------

function retrieveAllIssues() {
    let responseData = "";

    responseData.on('data', function (chunk) {
        responseData += chunk;
    });

    responseData.on('end', function () {
        let dataObj = JSON.parse(responseData);
        console.log("Raw Response: " + responseData);
        console.log("Message: " + dataObj.message);
        console.log("Question: " + dataObj.question);
    })
}

let req = http.request(options, retrieveAllIssues);
req.write('{"name":"Bilbo", "occupation":"Burglar"}');
req.end();
let retrieveAllIssues = http.request(optionsGet, function(res) {
    // I prefer single quotes, but this might be JSON data, so using double qoutes for now. 

    let str = "";

    res.on('data', function (chunk) {
        str += chunk;        
    });

    res.on('end', function () {
        console.log(str);
    })
})

let createIssue = http.request(optionsPost, function(res) {
    // I prefer single quotes, but this might be JSON data, so using double qoutes for now. 

    let str = "";

    res.on('data', function (chunk) {
        str += chunk;        
    });

    res.on('end', function () {
        console.log(str);
    })
})
*/